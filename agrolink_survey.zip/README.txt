AgroLink Survey - Pure JavaScript version
Files:
- index.html : single-file survey (RTL Kurdish)
How to use:
- Open index.html in your browser to run locally.
- To publish publicly: upload to GitHub repo and enable Pages or drop into Netlify (drag & drop).
